1:
svg资源-github
https://github.com/skishore/makemeahanzi

2: 
解压svgs文件

3:
执行程序