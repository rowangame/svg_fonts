package com.hanzi.svg;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import com.rwgframe.character.cell.CharacterCell;
import com.rwgframe.character.helper.GB2312Helper;
import com.rwgframe.character.helper.GB2312Record;

public class SvgAnalyze {
	private static final String SVG_SRC_FILE_FMT = "./trunk/res/svgs/%d.svg";
	
	private static final String SVG_OUT_FILE_FMT = "./trunk/out/%d.svg";
	
	private static final String SVG_DESC_FILE = "./trunk/res/character-cell-dict.txt";
	
	/**
	 * 得到汉字数据描述列表
	 * @param lstCells
	 * @return
	 */
	public static ArrayList<CharacterDataCell> getCharacterDataCellList(ArrayList<CharacterCell> lstCells) {
		ArrayList<CharacterDataCell> lstRlt = new ArrayList<CharacterDataCell>();
		for (int i = 0; i < lstCells.size(); i++) {
			CharacterCell tmpCell = lstCells.get(i);
			CharacterDataCell tmpDataCell = new CharacterDataCell();
			tmpDataCell.id = i;
			tmpDataCell.code = (int)tmpCell.getValue().charAt(0);
			tmpDataCell.value = tmpCell.getValue();
			GB2312Record tmpRecord = GB2312Helper.singleton().getRecord(tmpCell.getValue().charAt(0));
			tmpDataCell.pinyin = tmpRecord.getPingyin();
			tmpDataCell.strokes = tmpRecord.getBishun().length();
			lstRlt.add(tmpDataCell);
		}
		return lstRlt;
	}
	
	/**
	 * 将数据以json行数列表保存到文件中
	 * @param lstCells
	 * @return
	 */
	public static boolean saveCharacterDataCell(ArrayList<CharacterDataCell> lstCells) {
		try {			
			FileOutputStream fos = new FileOutputStream(SVG_DESC_FILE);
			OutputStreamWriter osw = new OutputStreamWriter(fos, "utf-8");
			BufferedWriter bw = new BufferedWriter(osw);
			for (int i = 0; i < lstCells.size(); i++) {
				CharacterDataCell tmpDataCell = lstCells.get(i);
				String tmpJson = JsonArrayUtil.getJsonString(tmpDataCell);
				bw.write(tmpJson);
				bw.newLine();
			}
			bw.flush();
			bw.close();
			System.out.println(String.format("保存成功！记录数=%d", lstCells.size()));
			return true;
		} catch (Exception e) {
			System.out.println(e.toString());
			return false;
		}
	}
	
	/**
	 * 根据汉字GB2312编码,返回svg文件内容
	 * @param cellValue
	 * @return
	 */
	public static ArrayList<String> getSvgFile(CharacterCell cellValue) {
		File tmpFile = new File(String.format(SVG_SRC_FILE_FMT, (int)cellValue.getValue().charAt(0))); 
		if (!tmpFile.exists() || !tmpFile.isFile()) {
			return null;
		}
		ArrayList<String> lstRlt = new ArrayList<String>();
		try {
			FileInputStream fis = new FileInputStream(tmpFile);
			InputStreamReader isr = new InputStreamReader(fis, "utf-8");
			BufferedReader br = new BufferedReader(isr);
			String aLine = null;
			while ((aLine = br.readLine()) != null) {
				String tmpLine = aLine.trim();
				if (tmpLine.length() > 0) {
					lstRlt.add(tmpLine);	
				}
			}
			br.close();
			return lstRlt;
		} catch (Exception e) {
			System.out.println(e.toString());
			return null;
		}
	}
	
		
	/**
	 * 从svg文件内提取笔顺数路径描述
	 * @param lstSvg svg文件内容
	 * @param cellValue
	 * @return
	 */
	public static ArrayList<String> fetchStrokes(ArrayList<String> lstSvg, CharacterCell cellValue) {
		// 路径开始标记
		final String start_tag = "</style>";
		// 路径内容标记
		final String ctx_tag = "<path d=";
		// 路径结束标记
		// final String end_tag = "<clipPath";
		
		try {
			ArrayList<String> lstRlt = new ArrayList<String>();
			boolean isError = false;
			// 查找路径开始标记
			for (int i = 0; i < lstSvg.size(); i++) {
				String tmpLine = lstSvg.get(i);
				if (tmpLine.equals(start_tag)) {
					// 根据汉字的笔顺数,得到路径数
					GB2312Record tmpRecord = GB2312Helper.singleton().getRecord(cellValue.getValue().charAt(0));
					// 得到汉字的笔顺数
					int tmpStrokes = tmpRecord.getBishun().length();
					for (int j = 1; j <= tmpStrokes; j++) {
						String tmpPath = lstSvg.get(i + j);
						if (!tmpPath.startsWith(ctx_tag)) {
							System.out.println(String.format("分析路径数据出错:value=%s,code=%d,start=%d errorIdx=%d", 
									cellValue.getValue(),
									(int)cellValue.getValue().charAt(0),
									i + 1, i + j));
							isError = true;
							lstRlt.clear();
							break;
						}
						lstRlt.add(tmpPath);
					}
					break;
				}
			}
			if (!isError) {
				return lstRlt;	
			} else {
				return null;
			}
		} catch (Exception e) {
			System.out.println(e.toString());
			return null;
		}
	}
	
	/**
	 * 根据svgPath路径数据生成svg文件
	 * @param lstSvgPath svgPath路径数据
	 * @param cellValue 汉字数据
	 * @return
	 */
	public static ArrayList<String> makeSvgFileBySvgPath(ArrayList<String> lstSvgPath, CharacterCell cellValue) {
		// svg开始标记(定义svg显示区域,宽度和高度.因原始svg文件是1024的宽度,所以需要定义1024的宽度和高度)
		final String svg_tart_tag = "<svg xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" viewBox=\"0 0 1024 1024\" width=\"1024\" height=\"1024\">";
	    final String svg_end_tag = "</svg>";
	    // 路径绘制开始标记
	    final String g_start_tag = "  <g transform=\"translate(%d, %.1f) scale(0.125, -0.125)\">";
	    // 路径绘制结束标记
	    final String g_end_tag = "  </g>";
	    
	    // 开始生成svg文件内容
	    ArrayList<String> lstRlt = new ArrayList<String>();
	    // 添加svg开始标记
	    lstRlt.add(svg_tart_tag);
	    
	    // 生成路径数据(按笔顺生成)
	    // 区域的宽度和高度
	    final int per_width = 128;
	    final int per_height = 128;
	    // 每一行显示的区域数(画布上每一行最多绘制的区域)
	    final int per_lines = 6;
	    // x,y起始值
	    final int start_x = 0;
	    final float start_y = 112.f;
	    
	    int strokes = lstSvgPath.size();
	    for (int i = 0; i < strokes; i++) {
	    	// 得到当前的笔画数
	    	int curStroke = i + 1;
	    	// 行数(下标值从0开始)
	    	int tmpRow = 0; 
	    	// 列数(下标值从0开始)
	    	int tmpCol = 0;
	    	if (curStroke % per_lines == 0) {
	    		tmpRow = curStroke / per_lines - 1;
	    		tmpCol = per_lines - 1;
	    	} else {
	    		tmpRow = curStroke / per_lines;
	    		tmpCol = curStroke % per_lines -1;
	    	}
	    	// 绘制开始标记
	    	String gStartInfo = String.format(g_start_tag, start_x + per_width * tmpCol, start_y + tmpRow * per_height);
	    	lstRlt.add(gStartInfo);
	    	
	    	// 路径数据
	    	for (int j = 0; j < curStroke; j++) {
	    		lstRlt.add("    " + lstSvgPath.get(j));
	    	}
	    	
	    	// 绘制结束标记
	    	lstRlt.add(g_end_tag);
	    }
	    
	    // 添加svg结束标记
	    lstRlt.add(svg_end_tag);
	    return lstRlt;
	}
	
	/**
	 * 将svg文件内容保存到文件内
	 * @param lstSvgs svg文件内容
	 * @param fileName 文件名
	 * @return
	 */
	public static boolean saveSvgContext(ArrayList<String> lstSvg, CharacterCell cellValue) {
		try {
			String fileName = String.format(SVG_OUT_FILE_FMT, (int)cellValue.getValue().charAt(0));
			
			FileOutputStream fos = new FileOutputStream(fileName);
			OutputStreamWriter osw = new OutputStreamWriter(fos, "utf-8");
			BufferedWriter bw = new BufferedWriter(osw);
			for (String tmpStr : lstSvg) {
				bw.write(tmpStr);
				bw.newLine();
			}
			bw.flush();
			bw.close();
			return true;
		} catch (Exception e) {
			System.out.println(e.toString());
			return false;
		}
	}
}
