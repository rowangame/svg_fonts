package com.hanzi.svg;

public class CharacterDataCell {
	// id
	public int id;
	
	// 编码值
	public int code;
	
	// 字符内容
	public String value;
	
	// 拼音
	public String pinyin;
	
	// 总笔画数
	public int strokes;
}
