package com.hanzi.svg;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

/**
 * Json数据类
 * 
 * @author xielunguo@cosonic.net
 * @since 2021-04-18
 */
public class JsonArrayUtil {
	/**
	 * <>禁止将特殊字符unicode编码
	 */
	private static final GsonBuilder gsonBuilder = new GsonBuilder().disableHtmlEscaping();
	
	private static JsonArray toJsonArray(String value[]) {
		JsonArray rlt = new JsonArray();
		if (value != null && value.length > 0) {
			JsonObject jsnTmp = new JsonObject();
			for (int i = 0; i < value.length; i++) {
				if (value[i] == null) continue;
				jsnTmp.addProperty("" + i, value[i]);
			}
		
			Set<Entry<String,JsonElement>> sets = jsnTmp.entrySet();
			for (Entry<String,JsonElement> entry : sets) {
				rlt.add(jsnTmp.get(entry.getKey()));
			}
		}
		return rlt;
	}
	
	private static JsonArray toJsonArray(Object value[]) {
		JsonArray rlt = new JsonArray();
		if (value != null && value.length > 0) {
			JsonObject jsnTmp = new JsonObject();
			for (int i = 0; i < value.length; i++) {
				if (value[i] == null) continue;
				jsnTmp.addProperty("" + i, value[i].toString());
			}
		
			Set<Entry<String,JsonElement>> sets = jsnTmp.entrySet();
			for (Entry<String,JsonElement> entry : sets) {
				rlt.add(jsnTmp.get(entry.getKey()));
			}
		}
		return rlt;
	}
	
	/**
	 * 得到json数据字符串
	 * @param value [String数组]
	 * @return
	 */
	public static String getArrayString(String value[]) {
		return toJsonArray(value).toString();
	}
	
	/**
	 * 得到json数据字符串
	 * @param value [Object数组]
	 * @return
	 */
	public static String getArrayString(Object value[]) {
		return toJsonArray(value).toString();
	}
	
	/**
	 * 得到json字符串[禁止对特殊编码]
	 * @param obj
	 * @return
	 */
	public static String getJsonString(Object obj) {
		Gson gson = gsonBuilder.create();
		return gson.toJson(obj);
	}
	
	/**
	 * 将json转化为对象
	 * @param json
	 * @param classOfT
	 * @return
	 */
	public static <T>T jsonToObject(String json,Class<T> classOfT) {
		try {
			//return new Gson().fromJson(json, classOfT);	
			return gsonBuilder.create().fromJson(json, classOfT);	
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 将json转化为对象
	 * @param json
	 * @param type
	 * @return
	 */
	public static <T>T jsonToArrayObject(String json,Type type) {
		try {
			//return new Gson().fromJson(json, type);
			return gsonBuilder.create().fromJson(json, type);
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * json转List列表
	 * @param <T>
	 * @param json
	 * @param clazz
	 * @return
	 */
    public static <T>List<T> jsonToArrayObject(String json,Class<T> clazz) {
    	try {
    		//Gson gson = new Gson();
    		Gson gson = gsonBuilder.create();
    		return gson.fromJson(json, new TypeToken<List<T>>(){}.getType());
    	} catch (Exception e) {
    		return null;
    	}
    }
    
    /**
     * 转化为json数组对象
     * @param json
     * @param typeOfT new TypeToken<List<E>>(){}.getType()
     * @return
     */
    public static <T>List<T> jsonToArrayObjectEx(String json,Type typeOfT) {
    	try {
    		Gson gson = gsonBuilder.create();
    		return gson.fromJson(json,typeOfT);
    	} catch (Exception e) {
    		return null;
    	}
    }
}
