package com.hanzi.svg;

import java.util.ArrayList;

import com.rwgframe.character.cell.CharacterCell;
import com.rwgframe.character.gb2312.GB2312Manager;
import com.rwgframe.character.helper.GB2312Helper;
import com.rwgframe.character.helper.GB2312Record;

public class SvgMain {
	private static ArrayList<CharacterCell> getAllCharacters() {
		GB2312Manager.singleton().initGB2312();
		ArrayList<CharacterCell> lstCells = GB2312Manager.singleton().getLst();
		return lstCells;
	}
	
	@SuppressWarnings("unused")
	private static void test() {
		GB2312Helper gbHelper = GB2312Helper.singleton();
		
		ArrayList<CharacterCell> lstCells = getAllCharacters();
		for (int i = 0; i < 1 && lstCells.size() > 0; i++) {
			CharacterCell tmpCell = lstCells.get(i);
			System.out.println(String.format("i=%d id=%d value=%s encode=%s", i, tmpCell.getIndex(), tmpCell.getValue(), tmpCell.getEncode()));
		    System.out.println((int)tmpCell.getValue().charAt(0));
		    
		    GB2312Record record = gbHelper.getRecord(tmpCell.getValue().charAt(0));
		    System.out.println(record.getValue());
		    System.out.println(record.getPingyin());
		    System.out.println(record.getBishun());
		}		
	}
		
	public static void main(String args[]) {
		ArrayList<CharacterCell> lstCells = getAllCharacters();
		// 输出json格式数据记录
		ArrayList<CharacterDataCell> lstData = SvgAnalyze.getCharacterDataCellList(lstCells);
		SvgAnalyze.saveCharacterDataCell(lstData);
		
		// 生成svg文件
		for (int i = 0; i < lstCells.size(); i++) {
			CharacterCell tmpCell = lstCells.get(i);
			System.out.println(String.format("i=%d id=%d value=%s index=%d", i, tmpCell.getIndex(), tmpCell.getValue(), (int)tmpCell.getValue().charAt(0)));
			
			ArrayList<String> lstSvgOrigin = SvgAnalyze.getSvgFile(tmpCell);
			ArrayList<String> lstPath = SvgAnalyze.fetchStrokes(lstSvgOrigin, tmpCell);
			ArrayList<String> lstSvgFile = SvgAnalyze.makeSvgFileBySvgPath(lstPath, tmpCell);
			SvgAnalyze.saveSvgContext(lstSvgFile, tmpCell);
			
			// break;
		}
	}
	
}
