
import json

"""
字符数据类
"""
class FontDataType(object):
    # 字符宽度(px)
    type_width = 128
    # 字符高度(px)
    type_height = 128

    # 字母和数字
    letter_type = 0
    # 常用汉字
    character_type = 1
    # 英文标点符号和调用特殊符号
    en_symbols_type = 2
    # 中文标点符号
    cn_symbols_type = 3

    def __init__(self):
        super(FontDataType, self).__init__()
        self.letter_dict = None
        self.character_dict = None
        self.en_dict = None
        self.cn_dict = None

    # 加载字典数据
    def loadDicts(self, type):
        paths = [
            "res/letter-symbols-dict.txt",
            "res/character-cell-dict.txt",
            "res/en-symbols-dict.txt",
            "res/cn-symbols-dict.txt"
        ]
        dic_file_path = paths[type]
        if not (type in [0, 1, 2, 3]):
            raise Exception("Error type")

        lstInfo = []
        txtFile = open(dic_file_path, 'r', encoding="utf-8")
        lines = txtFile.readlines()
        txtFile.close()
        # print('len(lines)=', len(lines))
        for i in range(0, len(lines)):
            # print('[%d]=%s' % (i, lines[i]))
            tmpDict = json.loads(lines[i])
            # print(tmpDict)
            lstInfo.append((tmpDict['id'], tmpDict['code'], tmpDict['value']))
        return lstInfo

    # 加载所有字典数据
    def loadAllDicts(self):
        self.letter_dict = self.loadDicts(FontDataType.letter_type)
        self.character_dict = self.loadDicts(FontDataType.character_type)
        self.en_dict = self.loadDicts(FontDataType.en_symbols_type)
        self.cn_dict = self.loadDicts(FontDataType.cn_symbols_type)

    # 当前字符(编码)是否存在字典中
    def exists(self, code):
        for i in range(len(self.letter_dict)):
            if self.letter_dict[i][1] == code:
                return self.letter_type, True
        for i in range(len(self.character_dict)):
            if self.character_dict[i][1] == code:
                return self.character_type, True
        for i in range(len(self.en_dict)):
            if self.en_dict[i][1] == code:
                return self.en_symbols_type, True
        for i in range(len(self.cn_dict)):
            if self.cn_dict[i][1] == code:
                return self.cn_symbols_type, True
        return -1, False

    # 得到单元二值图字符图像路径
    # type: 类型
    # code: 字符编码值
    def getImagePath(self, type, code):
        if type == FontDataType.letter_type:
            return "res/letter/%d.png" % code
        if type == FontDataType.character_type:
            return "res/character/%d.png" % code
        if type == FontDataType.en_symbols_type:
            return "res/en_symbols/%d.png" % code
        if type == FontDataType.cn_symbols_type:
            return "res/cn_symbols/%d.png" % code
        return None