"""
文字图像生成器
"""

import cv2
import numpy as np
from font_type import FontDataType

class FontGenerator:
    fontDataType: FontDataType = None
    # 缓存图像数据字典
    dictImg = dict()

    @classmethod
    def initFontType(cls):
        cls.fontDataType = FontDataType()
        cls.fontDataType.loadAllDicts()

    @classmethod
    def loadImg(cls, type, code):
        try:
            if code in cls.dictImg.keys():
                return cls.dictImg[code]
            path = cls.fontDataType.getImagePath(type, code)
            img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
            cls.dictImg[code] = img
            return img
        except Exception as e:
            print(repr(e))

    """
    chars: 输入的字符串
    color: 前景色RGB颜色值
    gb: 背景色
    savePath: 保存文件路径
    perHeight: 每个字符的调试
    spaceWidth: 空字符宽度
    spanWidth: 每个字符的间距
    """
    @classmethod
    def toFontImage(cls, chars: str, color: tuple[int, int, int], bg: tuple[int,int,int], savePath: str,
                    perHeight: int=128, spaceWidth: int=12, spanWidth: int=1):
        scale = 1.0 * perHeight / cls.fontDataType.type_height
        spaceWidth = int(scale * spaceWidth)
        # 总宽度
        total_width = 0
        img_src = []
        length = len(chars)
        for i in range(length):
            tmpChar = chars[i]
            tmpCode = ord(tmpChar)
            print(i, tmpCode, tmpChar)
            if tmpCode == 32: # 空格
                img_src.append(0)
                total_width += spaceWidth
                continue
            imgtype, boFind = cls.fontDataType.exists(ord(chars[i]))
            if not boFind:
                print(f"Error not found:{chars[i]}")
                return
            img = cls.loadImg(imgtype, ord(chars[i]))
            # 缩放处理
            scaleImg = cv2.resize(img, (int(scale * img.shape[1]), perHeight))
            img_src.append(scaleImg)
            # print(img.shape)
            total_width += scaleImg.shape[1]
        # 间距宽度
        total_width += (length + 1) * spanWidth
        # 初始化图片绥冲区
        outImg = np.zeros((perHeight, total_width, 3), dtype=np.uint8)
        # 白色背景填充
        outImg.fill(255)
        tmpIndex = spanWidth
        for i in range(length):
            if type(img_src[i]) == int:
                tmpIndex += spaceWidth
                continue
            srcImg = img_src[i]
            srcH, srcW = srcImg.shape[0], srcImg.shape[1]
            outImg[0: perHeight, tmpIndex: tmpIndex + srcW, 0] = srcImg[0: srcH, 0: srcW]
            outImg[0: perHeight, tmpIndex: tmpIndex + srcW, 1] = srcImg[0: srcH, 0: srcW]
            outImg[0: perHeight, tmpIndex: tmpIndex + srcW, 2] = srcImg[0: srcH, 0: srcW]
            tmpIndex += srcW + spanWidth
        # 填充颜色
        outH, outW = outImg.shape[0], outImg.shape[1]
        for tmpR in range(outH):
            for tmpC in range(outW):
                # 前景色
                if outImg[tmpR][tmpC][0] != 255:
                    outImg[tmpR][tmpC] = [color[2], color[1], color[0]]
                # 背景色
                else:
                    outImg[tmpR][tmpC] = [bg[2], bg[1], bg[0]]
        # 保存图片
        cv2.imwrite(savePath, outImg)