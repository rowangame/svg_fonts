
from font_generater import FontGenerator

FontGenerator.initFontType()
FontGenerator.toFontImage("Test font generator!", (0, 255, 0), (255,255,255), "out/test_font-32.png", 32, 16, 1)